
Paste this into the commandline to run one script or some commands again later..

# read settings from last run...

read  appn  sfil  sfil2  mpwd  parm0</tmp/"_brvar1202_${USER}".txt
echo $appn $sfil $sfil2 $mpwd $parm0

