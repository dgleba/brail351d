#!/usr/bin/env bash

### settings .. ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  
  
# this is older, setting from command line now..
  
  
# name for the new application..

# export appn='c6rail308'
export appn='dta2p'

# Location of creator files beside the new folder of the application..

export sfil='bashrail'

# Location modified for use after cd into the new app folder..

export sfil2='../'$sfil

 